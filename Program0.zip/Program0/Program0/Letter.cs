﻿//D3369
//Due: 9/10/2018
// Program 0
// Shows HAS-A relationship, polymorphism, throught chapters 12 by using a parcel letter system.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    public class Letter: Parcel  //derived class 
    {
        private decimal _fixedCosts; // declare variable 

        // Preconditions: get from derived class 
        // Postconditions: The letter item has been initialized with the spcified values for origin address, destination 
        //                 address, and fixed costs
        public Letter(Address _originAddress, Address _destinationAddress, decimal _fixedCosts)
            : base(_originAddress, _destinationAddress)
        {
            FixedCosts = _fixedCosts;
        }

        public decimal FixedCosts
        {
            // Preconditions: gets fixed cost 
            // Postconditions: fixed costs is returned
            get
            {
                return _fixedCosts;
            }
            // Preconditions: returns fixed cost 
            // Postconditions: Fixed costs is set to the specified value
            set
            {
                _fixedCosts = value;
            }
        }

        // Preconditions: overide to decimal calcost 
        // Postconditions: CalcCost is set to Fixed costs
        public override decimal CalcCost()
        {
            return FixedCosts;
        }

        // Preconditions: string interpolation 
        // Postconditions: A string is returned with the letter information
       
        public override string ToString() =>
           $"\n Orgin Address:{OriginAddress}\n Destination Address:{DestinationAddress}\n Cost:{FixedCosts:C}";
    }
}
