﻿//D3369
//Due: 9/10/2018
// Program 0
// Shows HAS-A relationship, polymorphism, throught chapters 12 by using a parcel letter system.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    public abstract class Parcel //abstract class 
    {
        public Address _originAddress;          // Origin address
        public Address _destinationAddress;     // Destination address

        // Preconditions: sets paramaters for parcel 
        // Postconditions: The parcel item is initialized with the specified values for origin address and destiation address
        public Parcel(Address _originAddress, Address _destinationAddress)
        {
            OriginAddress = _originAddress;
            DestinationAddress = _destinationAddress;

            CalcCost();
        }
        public Address OriginAddress
        {
            // Preconditions: get orgin address 
            // Postconditions: Origin address is returned
            get
            {
                return _originAddress;
            }
            // Preconditions: reetuned orgin address 
            // Postconditions: Origin address is set to the specified value
            set
            {
                _originAddress = value;
            }
        }

        public Address DestinationAddress
        {
            // Preconditions: get destination address 
            // Postconditions: Destination address is returned
            get
            {
                return _destinationAddress;
            }
            // Preconditions: returned destination address 
            // Postconditions: Destination address is set to the specified value
            set
            {
                _destinationAddress = value;
            }
        }

        // Preconditions: using publc abstract decimal 
        // Postconditions: The cost for the item is calculated 
        public abstract decimal CalcCost();

        // Preconditions: using string interpolation 
        // Postconditions: A string is returned presenting the parcel information on separate lines
      
        public override string ToString() =>
            $"\n Orgin Address:{OriginAddress}\n Destination Address:{DestinationAddress}\n Cost:{CalcCost():C}";


    }
}
