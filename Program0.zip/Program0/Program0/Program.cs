﻿//D3369
//Due: 9/10/2018
// Program 0
// Shows HAS-A relationship, polymorphism, throught chapters 12 by using a parcel letter system.




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    class Program
    {
        static void Main(string[] args)
        {
           // Creates 2 list from parcles and inizialie with 3 objects 
                List<Parcel> parcels = new List<Parcel>();      // List of parcels
                List<Address> addresses = new List<Address>();  // List of addresses

                addresses.Add(new Address(" John Doe", "4926 Apple grove Ln", "apt 1", "Louisville", "KY", 40218)); // address 1
            addresses.Add(new Address("Jessica Vega", "1801 park field dr", "apt 215", "Miami", "FL", 30512)); // Address 2
                addresses.Add(new Address("Julius Irving", "1234 Billie Jean Rd", "", "Memphis", "Tennesee", 32012));  // Address3
            addresses.Add(new Address("James Adkins", "7011 lefte baker st", "", "THomas", "Mississippi", 52030));  // Address4

                parcels.Add(new Letter(addresses[0], addresses[1], 1)); // Destination List 
                parcels.Add(new Letter(addresses[1], addresses[2], 2));
                 parcels.Add(new Letter(addresses[2], addresses[3], 3));

            //Precondition:Iterates loop trough for each until complete
            //POstcondition:Outputs results and cost
            foreach (Letter letter in parcels) // Increments for each letter in parcel
                    Console.WriteLine("{0}\n", letter); // Outputs results on screen 
            
        }
    }
}
