﻿//D3369
//Due: 9/10/2018
// Program 0
// Shows HAS-A relationship, polymorphism, throught chapters 12 by using a parcel letter system.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    public class Address
    {
        //Declares variables 
        private string Name { get; }           // Name
        private string AddressLine1 { get; }   // Address Line 1
        private string _addressLine2;           // Address Line 2
        private string City  { get; }           // City
        private string State { get; }           // State
        private int _zip;                       // Zip Code
        private int validZip =99999;           //holds valid zip <=99999

        // Preconditions: sets paramaters for address 
        // Postconditions: The address item has been initialized with the specified values for name, address line 1,
        //                 address line 2, city, state, and zip
        public Address(string _name, string _addressLine1, string _addressLine2, string _city,
            string _state, int _zip)
        {
            Name = _name;
            AddressLine1 = _addressLine1;
            AddressLine2 = _addressLine2;
            City = _city;
            State = _state;
            Zip = _zip;
        }     

        public string AddressLine2
        {
            // Preconditions: gets address line 2 if not null
            // Postconditions: The address line 2 has been returned unless null
            get
            {
                return _addressLine2;
            }
            // Preconditions: address 2 null or valid 
            // Postconditions: The address line 2 has been set to the specified value
            set
            {
                _addressLine2 = value;
            }
        }


        public int Zip
        {
            // Preconditions: gets valid zip 
            // Postconditions: gets zip
            get
            {
                return _zip;
            }
            // Preconditions: betwen 0 and 99999
            // Postconditions: The zip has been setplus validation that its between 0 and 99999
            set
            {
                if (_zip <= validZip)
                    _zip = value;
            }
        }
        // Preconditions:  valid to.string data and interpolation 
        // Postconditions: A string is returned with the data of the addresses 

      
        public override string ToString() =>
        $"{Name}\n {AddressLine1} ({AddressLine2}\n" +
        $"{City} {State} {Zip:D5}";//
            
        
    }
}

