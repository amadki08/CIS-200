﻿namespace UPVApp
{
    partial class Prog2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.insertToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.addressFormMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.lettersFormMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.listAddressToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.listParcelToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.reportTextBox = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.insertToolStrip,
            this.reportToolStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStrip,
            this.exitToolStrip});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // aboutToolStrip
            // 
            this.aboutToolStrip.Name = "aboutToolStrip";
            this.aboutToolStrip.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStrip.Text = "About";
            this.aboutToolStrip.Click += new System.EventHandler(this.aboutToolStrip_Click);
            // 
            // exitToolStrip
            // 
            this.exitToolStrip.Name = "exitToolStrip";
            this.exitToolStrip.Size = new System.Drawing.Size(107, 22);
            this.exitToolStrip.Text = "Exit";
            this.exitToolStrip.Click += new System.EventHandler(this.exitToolStrip_Click);
            // 
            // insertToolStrip
            // 
            this.insertToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addressFormMenuStrip,
            this.lettersFormMenuStrip});
            this.insertToolStrip.Name = "insertToolStrip";
            this.insertToolStrip.Size = new System.Drawing.Size(48, 20);
            this.insertToolStrip.Text = "Insert";
            // 
            // addressFormMenuStrip
            // 
            this.addressFormMenuStrip.Name = "addressFormMenuStrip";
            this.addressFormMenuStrip.Size = new System.Drawing.Size(180, 22);
            this.addressFormMenuStrip.Text = "Address";
            this.addressFormMenuStrip.Click += new System.EventHandler(this.addressFormMenuStrip_Click);
            // 
            // lettersFormMenuStrip
            // 
            this.lettersFormMenuStrip.Name = "lettersFormMenuStrip";
            this.lettersFormMenuStrip.Size = new System.Drawing.Size(180, 22);
            this.lettersFormMenuStrip.Text = "Letters";
            this.lettersFormMenuStrip.Click += new System.EventHandler(this.lettersFormMenuStrip_Click);
            // 
            // reportToolStrip
            // 
            this.reportToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.reportToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listAddressToolStrip,
            this.listParcelToolStrip});
            this.reportToolStrip.Name = "reportToolStrip";
            this.reportToolStrip.Size = new System.Drawing.Size(54, 20);
            this.reportToolStrip.Text = "Report";
            // 
            // listAddressToolStrip
            // 
            this.listAddressToolStrip.Name = "listAddressToolStrip";
            this.listAddressToolStrip.Size = new System.Drawing.Size(180, 22);
            this.listAddressToolStrip.Text = "List Addresses";
            this.listAddressToolStrip.Click += new System.EventHandler(this.listAddressToolStrip_Click);
            // 
            // listParcelToolStrip
            // 
            this.listParcelToolStrip.Name = "listParcelToolStrip";
            this.listParcelToolStrip.Size = new System.Drawing.Size(180, 22);
            this.listParcelToolStrip.Text = "List Parcels";
            this.listParcelToolStrip.Click += new System.EventHandler(this.listParcelToolStrip_Click);
            // 
            // reportTextBox
            // 
            this.reportTextBox.Location = new System.Drawing.Point(12, 27);
            this.reportTextBox.Multiline = true;
            this.reportTextBox.Name = "reportTextBox";
            this.reportTextBox.ReadOnly = true;
            this.reportTextBox.Size = new System.Drawing.Size(260, 222);
            this.reportTextBox.TabIndex = 1;
            // 
            // Prog2Form
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.reportTextBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Prog2Form";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStrip;
        private System.Windows.Forms.ToolStripMenuItem exitToolStrip;
        private System.Windows.Forms.ToolStripMenuItem insertToolStrip;
        private System.Windows.Forms.ToolStripMenuItem addressFormMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem lettersFormMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem reportToolStrip;
        private System.Windows.Forms.ToolStripMenuItem listAddressToolStrip;
        private System.Windows.Forms.ToolStripMenuItem listParcelToolStrip;
        private System.Windows.Forms.TextBox reportTextBox;
    }
}

