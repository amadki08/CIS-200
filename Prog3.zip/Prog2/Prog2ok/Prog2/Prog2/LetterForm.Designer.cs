﻿namespace Prog2
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.originAddressCB = new System.Windows.Forms.ComboBox();
            this.destinationAddressCB = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.costTB = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.letterErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.letterErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // originAddressCB
            // 
            this.originAddressCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.originAddressCB.FormattingEnabled = true;
            this.originAddressCB.Location = new System.Drawing.Point(188, 29);
            this.originAddressCB.Name = "originAddressCB";
            this.originAddressCB.Size = new System.Drawing.Size(121, 21);
            this.originAddressCB.TabIndex = 0;
            this.originAddressCB.Validating += new System.ComponentModel.CancelEventHandler(this.originAddressCB_Validating);
            this.originAddressCB.Validated += new System.EventHandler(this.originAddressCB_Validated);
            // 
            // destinationAddressCB
            // 
            this.destinationAddressCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destinationAddressCB.FormattingEnabled = true;
            this.destinationAddressCB.Location = new System.Drawing.Point(188, 85);
            this.destinationAddressCB.Name = "destinationAddressCB";
            this.destinationAddressCB.Size = new System.Drawing.Size(121, 21);
            this.destinationAddressCB.TabIndex = 1;
            this.destinationAddressCB.Validating += new System.ComponentModel.CancelEventHandler(this.destinationAddressCB_Validating);
            this.destinationAddressCB.Validated += new System.EventHandler(this.destinationAddressCB_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Orgin Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Destination Addresss";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Fixed Cost:";
            // 
            // costTB
            // 
            this.costTB.Location = new System.Drawing.Point(188, 133);
            this.costTB.Name = "costTB";
            this.costTB.Size = new System.Drawing.Size(121, 20);
            this.costTB.TabIndex = 5;
            this.costTB.Validating += new System.ComponentModel.CancelEventHandler(this.costTB_Validating);
            this.costTB.Validated += new System.EventHandler(this.costTB_Validated);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(256, 184);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 6;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            this.okButton.Validated += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(113, 184);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 7;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Validated += new System.EventHandler(this.cancelButton_Click);
            // 
            // letterErrorProvider
            // 
            this.letterErrorProvider.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 230);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.costTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.destinationAddressCB);
            this.Controls.Add(this.originAddressCB);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            ((System.ComponentModel.ISupportInitialize)(this.letterErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox originAddressCB;
        private System.Windows.Forms.ComboBox destinationAddressCB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox costTB;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider letterErrorProvider;
    }
}