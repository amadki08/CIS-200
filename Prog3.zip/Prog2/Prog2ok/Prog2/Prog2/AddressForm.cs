﻿//D3369
//Program 2 
//Due Oct 25,2018
//  This program explores the creation of a simple GUI, use of dialog boxes, validation, and exception handling.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        public AddressForm()
        {
            InitializeComponent();
            stateCB.SelectedIndex = 1; // default state set
        }


        public string AddressName
        {
            // Precondition: None
            // Postcondition:  name text is returned
            get { return nameTB.Text; }
            // Precondition: None
            // Postcondition:  name text is set to specified value
            set { nameTB.Text = value; }
        }

        public string AddressLine1
        {
            // Precondition: None
            // Postcondition: address text is returned
            get { return addressTB.Text; }
            // Precondition: None
            // Postcondition:  address text is set to specified value
            set { addressTB.Text = value; }
        }

        public string AddressLine2
        {
            // Precondition: None
            // Postcondition: address2 text is returned
            get { return address2TB.Text; }
            // Precondition: None
            // Postcondition: address2 text is set to specified value
            set { address2TB.Text = value; }
        }

        public string AddressCity
        {
            // Precondition: None
            // Postcondition: city Text is returned
            get { return cityTB.Text; }
            // Precondition: None
            // Postcondition: Text in cityTextBox is set to a specified value
            set { cityTB.Text = value; }
        }

        public string AddressState
        {
            // Precondition: None
            // Postcondition:  selected item from  combo box is returned
            get { return stateCB.SelectedItem.ToString(); }
        }

        public string AddressZip
        {
            // Precondition: None
            // Postcondition: Zip text is returned
            get { return zipTB.Text; }
            // Precondition: None
            // Postcondition: zip Text is set to specified value
            set { zipTB.Text = value; }
        }

        // Precondition: nameTextBox_Validating succeeded
        // Postcondition: Error message is cleared, focus is allowed to change

        private void nameTB_Validated(object sender, EventArgs e)
        {
            addressErrorProvider.SetError(nameTB, ""); // clears error message
        }
        private void AddressForm_Load(object sender, EventArgs e)
        {

        }
        // Precondition: Attempting to change focus from text box
        // Postcondition: If entered value is valid, focus will change,
        //                else focus will remain and error provider message set
        private void nameTB_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameTB.Text))
            {
                e.Cancel = true; // stops focus from changing

                addressErrorProvider.SetError(nameTB, "Don't leave the text box empty"); // sets error message
            }
        }

        // Precondition: address1 TextBox_Validating succeeded
        // Postcondition: Error message is cleared, focus is allowed to change
        private void addressTB_Validated(object sender, EventArgs e)
        {
            addressErrorProvider.SetError(addressTB, ""); // clears error message
        }

        // Precondition: Attempting to change focus from text box
        // Postcondition: If entered value is valid, focus will change,
        //                else focus will remain and error provider message set
        private void addressTB_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(addressTB.Text))
            {
                e.Cancel = true; // stops focus from changing

                addressErrorProvider.SetError(addressTB, "Don't leave the text box empty"); // sets error message
            }
        }

        // Precondition: cityTextBox _Validating succeeded
        // Postcondition: Error message is cleared, focus is allowed to change
        private void cityTB_Validated(object sender, EventArgs e)
        {
            addressErrorProvider.SetError(cityTB, ""); // clears error message
        }

        // Precondition: Attempting to change focus from text box
        // Postcondition: If entered value is valid, focus will change,
        //                else focus will remain and error provider message set
        private void cityTB_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cityTB.Text))
            {
                e.Cancel = true; // stops focus from changing

                addressErrorProvider.SetError(cityTB, "Don't leave the text box empty"); // sets error message
            }
        }

        // Precondition: zipTextBox_Validating succeeded
        // Postcondition: Error message is cleared, focus is allowed to change
        private void zipTB_Validated(object sender, EventArgs e)
        {
            addressErrorProvider.SetError(zipTB, ""); // clears error message
        }

        // Precondition: Attempting to change focus from text box
        // Postcondition: If entered value is valid, focus will change,
        //                else focus will remain and error provider message set
        private void zipTB_Validating(object sender, CancelEventArgs e)
        {
            int zip;
            if ((!int.TryParse(zipTB.Text, out zip)) && (zip >= 0) && (zip <= 99999))
            {
                e.Cancel = true; // stops focus from changing

                addressErrorProvider.SetError(zipTB, "Please enter an interger"); // sets error message
            }
            else
            {
                if ((zip < 0) || (zip > 99999))
                {
                    e.Cancel = true; // stops focus from changing

                    addressErrorProvider.SetError(zipTB, "Please enter an interger between 0 and 99999");
                }
            }
        }

        // Precondition: Ok button was clicked
        // Postcondition: If all controls on form validate, address form is dismissed with an OK result 


        // Precondition: Cancel button was clicked
        // Postcondition: Address form is dismissed with a Cancel result.

        private void okButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void cancelButton_Click_1(object sender, EventArgs e)
        {
            
                this.DialogResult = DialogResult.Cancel;
            

        }

        private void okButton_Click(object sender, MouseEventArgs e)
        {

        }
    }
}
