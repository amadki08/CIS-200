﻿namespace Prog2
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.addressTB = new System.Windows.Forms.TextBox();
            this.cityTB = new System.Windows.Forms.TextBox();
            this.zipTB = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            this.zipLabel = new System.Windows.Forms.Label();
            this.AddressLabel = new System.Windows.Forms.Label();
            this.stateCB = new System.Windows.Forms.ComboBox();
            this.address2TB = new System.Windows.Forms.TextBox();
            this.addressErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.cancelButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.addressErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(166, 31);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(100, 20);
            this.nameTB.TabIndex = 0;
            this.nameTB.Validating += new System.ComponentModel.CancelEventHandler(this.nameTB_Validating);
            this.nameTB.Validated += new System.EventHandler(this.nameTB_Validated);
            // 
            // addressTB
            // 
            this.addressTB.Location = new System.Drawing.Point(166, 63);
            this.addressTB.Name = "addressTB";
            this.addressTB.Size = new System.Drawing.Size(100, 20);
            this.addressTB.TabIndex = 1;
            this.addressTB.Validating += new System.ComponentModel.CancelEventHandler(this.addressTB_Validating);
            this.addressTB.Validated += new System.EventHandler(this.addressTB_Validated);
            // 
            // cityTB
            // 
            this.cityTB.Location = new System.Drawing.Point(166, 123);
            this.cityTB.Name = "cityTB";
            this.cityTB.Size = new System.Drawing.Size(100, 20);
            this.cityTB.TabIndex = 2;
            this.cityTB.Validating += new System.ComponentModel.CancelEventHandler(this.cityTB_Validating);
            this.cityTB.Validated += new System.EventHandler(this.cityTB_Validated);
            // 
            // zipTB
            // 
            this.zipTB.Location = new System.Drawing.Point(166, 185);
            this.zipTB.Name = "zipTB";
            this.zipTB.Size = new System.Drawing.Size(100, 20);
            this.zipTB.TabIndex = 3;
            this.zipTB.Validating += new System.ComponentModel.CancelEventHandler(this.zipTB_Validating);
            this.zipTB.Validated += new System.EventHandler(this.zipTB_Validated);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(91, 38);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 5;
            this.NameLabel.Text = "Name";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(102, 123);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(24, 13);
            this.cityLabel.TabIndex = 6;
            this.cityLabel.Text = "City";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(94, 149);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(32, 13);
            this.stateLabel.TabIndex = 7;
            this.stateLabel.Text = "State";
            // 
            // zipLabel
            // 
            this.zipLabel.AutoSize = true;
            this.zipLabel.Location = new System.Drawing.Point(104, 188);
            this.zipLabel.Name = "zipLabel";
            this.zipLabel.Size = new System.Drawing.Size(22, 13);
            this.zipLabel.TabIndex = 8;
            this.zipLabel.Text = "Zip";
            // 
            // AddressLabel
            // 
            this.AddressLabel.AutoSize = true;
            this.AddressLabel.Location = new System.Drawing.Point(81, 66);
            this.AddressLabel.Name = "AddressLabel";
            this.AddressLabel.Size = new System.Drawing.Size(45, 13);
            this.AddressLabel.TabIndex = 10;
            this.AddressLabel.Text = "Address";
            // 
            // stateCB
            // 
            this.stateCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stateCB.FormattingEnabled = true;
            this.stateCB.Items.AddRange(new object[] {
            "KY",
            "LA",
            "NY",
            "NJ"});
            this.stateCB.Location = new System.Drawing.Point(145, 149);
            this.stateCB.Name = "stateCB";
            this.stateCB.Size = new System.Drawing.Size(121, 21);
            this.stateCB.TabIndex = 11;
            // 
            // address2TB
            // 
            this.address2TB.Location = new System.Drawing.Point(166, 89);
            this.address2TB.Name = "address2TB";
            this.address2TB.Size = new System.Drawing.Size(100, 20);
            this.address2TB.TabIndex = 12;
            // 
            // addressErrorProvider
            // 
            this.addressErrorProvider.ContainerControl = this;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(94, 235);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 13;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click_1);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(233, 235);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 14;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.okButton_Click);
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 270);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.address2TB);
            this.Controls.Add(this.stateCB);
            this.Controls.Add(this.AddressLabel);
            this.Controls.Add(this.zipLabel);
            this.Controls.Add(this.stateLabel);
            this.Controls.Add(this.cityLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.zipTB);
            this.Controls.Add(this.cityTB);
            this.Controls.Add(this.addressTB);
            this.Controls.Add(this.nameTB);
            this.Name = "AddressForm";
            this.Text = "AddressForm";
            this.Load += new System.EventHandler(this.AddressForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.addressErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox addressTB;
        private System.Windows.Forms.TextBox cityTB;
        private System.Windows.Forms.TextBox zipTB;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.Label zipLabel;
        private System.Windows.Forms.Label AddressLabel;
        private System.Windows.Forms.ComboBox stateCB;
        private System.Windows.Forms.TextBox address2TB;
        private System.Windows.Forms.ErrorProvider addressErrorProvider;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
    }
}