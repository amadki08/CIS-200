﻿//D3369
// Due 9/24/2018
// Program 1B
//This program explores the creation of a simple class hierarchy including (limited) use of polymorphism.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{// public class derived from package 
    public class GroundPackage : Package
    {
        // Precondition: none
        // Postcondition: constructor that specifies orgin and destination address, lengthh, width, height, and weight)
        public GroundPackage(Address originAddress, Address destAddress,
        double length, double width, double height, double weight)
: base(originAddress, destAddress, length, width, height, weight)
        { 
        }

        const int FIRSTDIGIT_DENOMINATOR= 1000; // MAGIC NUMBER DECLARED FOR DENOMINATOR VALUE 
        public int ZoneDistance // declares a propterty for Zone Distance
        {
            // Precondition:  must have a valid origin and destination address
            // Postcondition: returns the difference between the first digits of the origin
            //                and destination zip codes
            
            get
            {
                return Math.Abs(OriginAddress.Zip / FIRSTDIGIT_DENOMINATOR
                  - DestinationAddress.Zip / FIRSTDIGIT_DENOMINATOR);
            }
        }
        // Precondition:  None
        // Postcondition: returns the cost of shipping a Ground Package
        public override decimal CalcCost()
        {
            const double DIM_COEFICENT = 0.20;
            const double WEIGHT_COEFICENT = .05;
            

            return Convert.ToDecimal(DIM_COEFICENT* (Length + Width + Height) + WEIGHT_COEFICENT * (ZoneDistance + 1) * (Weight));

        }
        // Precondition:  None
        // Postcondition: returns a string from parcel, package ground package and calccost 
        public override string ToString()
        {
            return $"Ground Package{Environment.NewLine}{base.ToString()}{Environment.NewLine}Zone Distance: {ZoneDistance}{Environment.NewLine}Cost: {CalcCost()}";
        }
    }
}
