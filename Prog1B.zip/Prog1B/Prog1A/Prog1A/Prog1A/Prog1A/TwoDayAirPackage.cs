﻿//D3369
// Due 9/24/2018
// Program 1B
//This program explores the creation of a simple class hierarchy including (limited) use of polymorphism.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    // two day derived from air package 
    public class TwoDayAirPackage : AirPackage
    {
        public enum Delivery { Early, Saver } // enum for delivery type early and saver
        // constructor of orgin address, desination address, lenght, width, height, weight, delivery type)
        public TwoDayAirPackage(Address orginAddress, Address destinAddress, double length, double width, double height, double weight, Delivery deliveryType)
            : base(orginAddress, destinAddress, length, width, height, weight)
        {
            DeliveryType = deliveryType;
        }
        //Precondition: none 
        //Postcondition: gets and set delivery type 

        public Delivery DeliveryType
        {
            get;



            set;
            
        }
        //Preconditions: none 
        //Postconditions: overides calcost for two day 
        public override decimal CalcCost()
        {
           //Base Cost(in dollars) = .25 * (Length + Width + Height) + .25 * (Weight)
            //If the package is Saver delivery type, the final cost will be reduced by 10 % (or, in other words, final cost will be 90 % of the base cost).
            const decimal DISCOUNT= .90M; // discount for saver declared 
            decimal cost; // cost declared variable 
            decimal baseCost; // base cost declared variable 
            const double MULTIPLIER = .25; // multiplier for  .25
            baseCost = Convert.ToDecimal((MULTIPLIER * (Length + Width + Height) + MULTIPLIER * (Weight))); // declared basecost and calulations with conversion to decimal 

            if (DeliveryType == Delivery.Saver) // determines if saver to recieve siscount or not 
                cost = baseCost * DISCOUNT;
            else
                cost = baseCost;

            return cost; // returns cost 

        }
        //precondition: none
        //postcondition: overide string to show two day, delivery type and cost 
        public override string ToString()
        {
            return $"Two Day Air Package{Environment.NewLine}{base.ToString()}{Environment.NewLine}Delivery Type: {DeliveryType}{Environment.NewLine}Cost: {CalcCost()}" ;
        }


    }
}
