﻿//D3369
// Due 9/24/2018
// Program 1B
//This program explores the creation of a simple class hierarchy including (limited) use of polymorphism.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    // derived abstract class from parcel 
    public abstract class Package : Parcel
    {

        private double _length; // declares length
        private double _width; // declares width 
        private double _height; // declares height
        private double _weight; // declares weight

        //Preconditions:none
        //Postconditions: constructors that include orgin address, destanitin address, length, width, height, weight 

        public Package(Address orginAddress, Address destAddress, double length, double width, double height, double weight)
        : base (orginAddress, destAddress)
        {
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;
        }
        //Preconditions:must be >= 0 
        //Postconditions: returns length 
        public double Length
        {
            get
            {
                return _length;
            }
            set
            {
                if (value >= 0)
                    _length = value;
                else
                    throw new ArgumentOutOfRangeException("Length", value,
    "Length must be >= 0");
            }
        }
        //Preconditon: value must be >= 0
        //postcondition: returns width 
        public double Width
        {
            get
            {
                return _width;
            }
            set
            {
                if (value >= 0)
                    _width = value;
                else
                    throw new ArgumentOutOfRangeException("Width", value,
    "Width must be >= 0");
            }
        }
        //precondition: value must be >=0
        //postcondition: returns height 
        public double Height
        {
            get
            {
                return _height;    
            }
            set
            {
                if (value >= 0)
                    _height = value;
                else
                    throw new ArgumentOutOfRangeException("Height", value,
    "Height must be >= 0");
            }
        }

        //precondition: value must be >=0
        //postcondition: returns value for weight 
        public double Weight
        {
            get
            {
                return _weight;
            }
            set
            {
                if (value >= 0)
                    _weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight", value, "Weight must be >=0");
            }
        }
        // precondition: none
        //postcondition: returns overrided string with length, width, height, and weight 

            public override string ToString()
        {
            return $"{base.ToString()}{Environment.NewLine}Length: {Length}{Environment.NewLine}Width: {Width}{Environment.NewLine}Height: {Height}{Environment.NewLine}Weight: {Weight}";
        }
    }



         
       
            
    }

