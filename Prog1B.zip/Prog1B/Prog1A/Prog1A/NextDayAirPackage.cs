﻿//D3369
// Due 9/24/2018
// Program 1B
//This program explores the creation of a simple class hierarchy including (limited) use of polymorphism.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{// nextdayair package class derived from air package 
    public class NextDayAirPackage : AirPackage
    {
        public decimal _expressfee; // declares express fee value 

        //precondition: none
        //postcondition: constructor that specifies orgin address, dest address, length, width, height, weight and express fee
        public NextDayAirPackage(Address orginAddress, Address destAddress, double length, double width, double height, double weight, decimal expressfee) 
        : base (orginAddress, destAddress, length, width, height, weight)
        {

        }
        //Precondition: none 
        //Postcondition: gets and returns express fee 
          public decimal ExpressFee
        {
            get
            {
                return _expressfee;
            }
        }

        //Precondition: none 
        //Postcondition: overides calccost for next day air packages 
            public override decimal CalcCost()
        {
            //            Base Cost(in dollars) = .40 * (Length + Width + Height) + .30 * (Weight) + ExpressFee
            //If the package is heavy, add a weight charge of
            //Weight Charge(in dollars) = .25 * (Weight)
            //If the package is large, add a size charge of
            //Size Charge(in dollars) = .25 * (Length + Width + Height)
            decimal baseCost; // declares a variable to hold the base cost of shipping a Next Day Air Package
            decimal weightCharge = Convert.ToDecimal(.25 * (Weight)); // declares a variable to hold the additional weight charge if the package is too heavy with calculations 
            decimal sizeCharge = Convert.ToDecimal(.25 * (Length + Width + Height)); // declares a variable to hold the additional size charge if the package is too large with calculations 
            decimal cost; // declares a variable to hold the final cost of shipping a Next day Air Package
            const double FIRST_MULTIPLIER = .40; // multiplier by double .40
           const double SEC_MULTIPLIER = .30;// multiplier by double .30

            baseCost = Convert.ToDecimal(FIRST_MULTIPLIER * (Length + Width + Height) + SEC_MULTIPLIER * (Weight)) + ExpressFee; //declares basecost with calculation of basecost 

            if (IsHeavy() == true && IsLarge() == true) 
                cost = baseCost + weightCharge + sizeCharge;

            else if (IsHeavy() == true)
                cost = baseCost + weightCharge;

            else if (IsLarge() == true)
                cost = baseCost + sizeCharge;

            else
                cost = baseCost;

            return cost;
        }
        // Precondition: none
        //Postcondition: string overides for next day air packages with express fee and cost 
              public override string ToString()
        {
            return $"Next Day Air Package{Environment.NewLine}{base.ToString()}{Environment.NewLine}Express Fee: {ExpressFee}{Environment.NewLine}Cost:{CalcCost()}";
        }


    }
    }




    
   





