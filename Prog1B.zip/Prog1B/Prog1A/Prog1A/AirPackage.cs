﻿//D3369
// Due 9/24/2018
// Program 1B
//This program explores the creation of a simple class hierarchy including (limited) use of polymorphism.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
   public abstract class  AirPackage : Package 
    {
        const int HEAVY_BOX = 75; // min weight of heavy box
        const int LARGE_BOX = 100; // min weight of large box 

        // Precondition:  None
        // Postcondition: The air package constructor is specified with parameters for origin, and destination
        //                addresses, length, width, height, and weight    
        public AirPackage(Address originAddress, Address destAddress,
               double length, double width, double height, double weight) :
               base(originAddress, destAddress, length, width, height, weight)
        {

        }
        // Precondition:  weight must hold a non negative value
        // Postcondition: returns a bool value to confirm if the air package is 
        //                deemed "Heavy" or not  
        public bool IsHeavy()
        {
            if (Weight >= HEAVY_BOX)
                return true;
            else
                return false;
        }
        // Precondition:  length+Width+Height must hold a non negative value
        // Postcondition: returns a bool value to confirm if the air package is 
        //                deemed "Large" or not  
        public bool IsLarge()
        {
            if (Length + Width + Height >= LARGE_BOX)
                return true;
            else
                return false;
        }

        // Precondition:  None
        // Postcondition: returns a string with  parcel, package and air package
        public override string ToString()
        {
            return $"{base.ToString()}{Environment.NewLine}Package is Heavy: {IsHeavy()}{Environment.NewLine}Package is Large: {IsLarge()}";
        }

    }

}

